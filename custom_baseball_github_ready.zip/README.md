# Custom Baseball PR — Glove Builder

Versión móvil/PWA lista para GitHub y Vercel.

## Importante
`index.html` debe estar en la raíz del repositorio.

## Capas independientes
- Leather 1–8
- Binding
- Palm
- Wrist / Muñeca
- Webs
- Lace / Cordones
- Welting
- Interior Leather
- Stitching / Costuras
- Wingtip Pinky
- Wingtip Thumb

Los colores de cada capa se conservan entre las cuatro vistas del guante.

## Archivos
- index.html
- manifest.webmanifest
- sw.js
- icon-180.png
- icon-192.png
- icon-512.png
- .nojekyll
- vercel.json

No requiere build, npm ni framework.
