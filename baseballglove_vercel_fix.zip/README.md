# Baseball Glove - GitHub/Vercel

Sube ESTOS ARCHIVOS DIRECTAMENTE a la raíz del repositorio.
No subas la carpeta completa como una subcarpeta.

El archivo principal debe verse así en GitHub:
`/index.html`

Vercel:
- Framework Preset: Other
- Root Directory: ./
- Build Command: vacío
- Output Directory: vacío
- Después: Redeploy
